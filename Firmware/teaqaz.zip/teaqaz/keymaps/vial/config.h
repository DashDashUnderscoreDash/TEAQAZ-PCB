/* SPDX-License-Identifier: GPL-2.0-or-later */

#pragma once

#define VIAL_KEYBOARD_UID {0x87, 0x1D, 0x74, 0x09, 0xAB, 0xE7, 0x2A, 0x05}

#define VIAL_UNLOCK_COMBO_ROWS {0}
#define VIAL_UNLOCK_COMBO_COLS {0}
